Mon projet fil rouge se nomme Pokétools. Pour le réaliser, j'ai utilisé Tailwind en tant que framework CSS.
Le but final de mon projet est d'avoir 3 pages fonctionnelles.
La première est un codex, qui donnerait toutes les informations utiles dans Pokémon, à savoir les Pokémon eux-mêmes, les objets et les capacités.
La deuxième est un calculateur de dégâts, prenant en compte les nombreux facteurs que l'on retrouve dans la licence.
La dernière est un team builder, servant à créer une team de Pokémon, avec leurs objets, talents et capacités, tout en ayant accès à leur couverture offensive et défensive.
Pour le TP, je me suis concentrée sur le codex. Celui-ci fait un appel API afin de retourner le sprite des Pokémon, leurs noms, leurs types, leurs ID ainsi que leurs descriptions. La prochaine étape sera de créer une page complète pour chaque Pokémon.